module.exports = {
  tokens: "8387428585:AAEbwdktkRbXwXqPxbnzcZZ2y1SzAx9IjjI",  // Ubah Jadi Token Bot Mu !!!
  owner: "7955761313", // Ubah Jadi Id Mu !!!
  port: "3024", // Ubah Jadi Port Panel Mu !!!
  ipvps: "0.0.0.0" // Ubah Jadi Ip Vps Mu !!!
};